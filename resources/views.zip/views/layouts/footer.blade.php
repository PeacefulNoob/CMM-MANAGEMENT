<footer class="">

    <div class="footer1 row paddinglra mx-0">
    <div class="col-4">
        <ul class="list-unstyled footerLista">
            <li>
            <h2>Section 1</h2>        
            </li>
            <li>
                <a target="_blank" href="#">Page 1</a>
            </li>
            <li>
                <a  target="_blank" href="#">  Page 2</a>
            </li>
            <li>
                <a  target="_blank" href="#"> Page 3</a>
            </li>
            <li>
                <a  target="_blank" href="#">Page 4</a>
            </li>
            <li>
                <a target="_blank"  href="#"> Page 5</a>
            </li>
        
    
        </ul>
    </div>
    <div class="col-4">  <ul class="list-unstyled footerLista">
        <li>
            <h2>Section 2</h2>        
            </li>
        <li>
            <div class="d-flex">
            <div> Adress :</div>    
            <div>
              <p>Adress 1, Budva, Montenegro</p>
              <p>  Adress 2, Moskow, Russia</p>
            </div>
            </div>
        </li>
        <li>
            <div class="d-flex">
                <div> Telefon:</div>    
                <div>+382 00 000 000</div>   
            </div>   
        </li>
        <li>
            <div class="d-flex">
                <div> Email adresa:</div>    
                <div>email@cmm.me</div>   
            </div>   
        </li>
        <li>
           <ul>
               <li>Facebook</li>
               <li>Instagram</li>
               <li>Twitter</li>
           </ul>
        </li>
    
    
    </ul></div>
    <div class="col-4">  <ul class="list-unstyled footerLista">
        <li>
            <h2>Section 3</h2>        
            </li>
        <li>
            <a target="_blank" href="#">Link 1</a>
        </li>
        <li>
            <a  target="_blank" href="#">  Link 2 </a>
        </li>
        <li>
            <a  target="_blank" href="#">Link 3</a>
        </li>
        <li>
            <a  target="_blank" href="#">Link 4</a>
        </li>
        <li>
            <a target="_blank"  href="#"> Link 5</a>
        </li>
    
    
    </ul></div>
    
    </div>
    
    <div class="footer2">
    <div class="left_footer"> 
        <p>All rights - CMM</p>
    </div>
    <div class="right_footer"> 
        <p>Made by QQRIQ</p>
    </div>
    </div>
    
    
    </footer>